#!/bin/bash
[ -t 1 ] && . /dog/colors

pip3 install ecdsa

echo -e "${GREEN}> install script complete${WHITE}"

