export default class IPFSpinner {
}
//# sourceMappingURL=IPFSpinner.js.map