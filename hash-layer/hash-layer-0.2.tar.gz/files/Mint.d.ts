import './load-env.js';
//# sourceMappingURL=Mint.d.ts.map