import './load-env.js';
//# sourceMappingURL=MinerWorker.d.ts.map