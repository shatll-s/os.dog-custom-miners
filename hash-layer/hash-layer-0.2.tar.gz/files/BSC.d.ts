export default class BSC {
    getHashBytes(height: bigint, previous_hash: Uint8Array, nonce: bigint, data: Uint8Array): Buffer<ArrayBufferLike>;
}
//# sourceMappingURL=BSC.d.ts.map