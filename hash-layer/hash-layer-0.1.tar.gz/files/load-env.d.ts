export declare const config: {
    readonly mnemonic: string | undefined;
};
//# sourceMappingURL=load-env.d.ts.map