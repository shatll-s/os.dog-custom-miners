export default class NFTstore {
    private helia;
    private hfs;
    init(): Promise<void>;
    upload(svg: string): Promise<string | undefined>;
}
//# sourceMappingURL=NFTstore.d.ts.map