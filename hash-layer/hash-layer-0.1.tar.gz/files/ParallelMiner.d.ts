export {};
//# sourceMappingURL=ParallelMiner.d.ts.map