export {};
//# sourceMappingURL=test-m-array.d.ts.map