export {};
//# sourceMappingURL=test-blake2b-detailed.d.ts.map