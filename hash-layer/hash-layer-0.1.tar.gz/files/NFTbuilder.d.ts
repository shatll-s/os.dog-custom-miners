export default class NFTbuilder {
    constructor();
    generate(): string;
    save(svg: string, filename?: string): void;
}
//# sourceMappingURL=NFTbuilder.d.ts.map