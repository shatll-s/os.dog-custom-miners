export default class IPFSpinner {
}
//# sourceMappingURL=IPFSpinner.d.ts.map