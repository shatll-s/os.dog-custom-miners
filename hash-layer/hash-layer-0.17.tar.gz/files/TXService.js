import { Transaction } from "@mysten/sui/transactions";
import { Ed25519Keypair } from "@mysten/sui/keypairs/ed25519";
export default class TXService {
    client;
    keypar;
    contractId;
    constructor(client, mnemonic, contractId) {
        this.client = client;
        if (!mnemonic)
            throw new Error("Mnemonic is required for Submitter");
        if (!contractId)
            throw new Error("ContractId is required for Submitter");
        this.keypar = Ed25519Keypair.deriveKeypair(mnemonic, "m/44'/784'/0'/0'/0'");
        this.contractId = contractId;
    }
    async createMintTx(controller, keeper) {
        const tx = new Transaction();
        tx.moveCall({
            target: `${this.contractId}::hash_layer::mint`,
            arguments: [tx.object(controller), tx.object(keeper)],
        });
        tx.setGasPrice(495);
        tx.setGasBudget(3500000);
        // Avoid locked gas coins
        await this.setAvailableGasCoin(tx);
        return tx;
    }
    async createTx(nonce, data, imageUrl, chainId, keeper) {
        const tx = new Transaction();
        tx.moveCall({
            target: `${this.contractId}::hash_layer::create_block`,
            arguments: [
                tx.pure.u64(nonce),
                tx.pure.vector("u8", data), // <vector<u8>>
                tx.pure.vector("u8", imageUrl), // vector<u8>
                tx.object(chainId),
                tx.object.clock(),
                tx.object(keeper),
            ],
        });
        tx.setGasPrice(495);
        tx.setGasBudget(1500000);
        // Avoid locked gas coins
        await this.setAvailableGasCoin(tx);
        return tx;
    }
    async sumbitBlock(nonce, data, imageUrl, chainId, keeper) {
        if (!imageUrl)
            throw new Error("imageUrl is required");
        if (!chainId)
            throw new Error("chainId is required");
        if (!keeper)
            throw new Error("keeper is required");
        try {
            const tx = await this.createTx(nonce, data, imageUrl, chainId, keeper);
            const result = await this.client.executeTransaction(tx, this.keypar);
            return result;
        }
        catch (err) {
            throw err;
        }
    }
    async mintCoins(controller, keeper) {
        if (!controller)
            throw new Error("imageUrl is required");
        if (!keeper)
            throw new Error("keeper is required");
        try {
            const tx = await this.createMintTx(controller, keeper);
            const result = await this.client.executeTransaction(tx, this.keypar);
            return result;
        }
        catch (err) {
            throw err;
        }
    }
    /**
     * Set an available (non-locked) gas coin for the transaction
     */
    async setAvailableGasCoin(tx) {
        try {
            const address = this.keypar.getPublicKey().toSuiAddress();
            const coins = await this.client.client.getCoins({ owner: address });
            // Known locked coin - avoid it
            const lockedCoin = "0x4e18ddd09248b696a32ef2b655985121dc997ab16242fca21d47f869a279b036";
            const availableCoins = coins.data.filter(c => c.coinObjectId !== lockedCoin);
            if (availableCoins.length > 0) {
                const gasPayment = availableCoins[0];
                tx.setGasPayment([{
                        objectId: gasPayment.coinObjectId,
                        version: gasPayment.version,
                        digest: gasPayment.digest
                    }]);
            }
            // If no available coins, let SDK choose (will probably fail with locked error)
        }
        catch (err) {
            // If anything fails, just let SDK choose gas coin automatically
            console.warn("Could not set specific gas coin, using SDK default");
        }
    }
}
//# sourceMappingURL=TXService.js.map