import './load-env.js';
import SuiClient from "./SuiClient.js";
import TXService from "./TXService.js";
import { Ed25519Keypair } from "@mysten/sui/keypairs/ed25519";
class Mint {
    client;
    tx;
    constructor() {
        this.client = new SuiClient(process.env.RPC_PROVIDER);
        this.tx = new TXService(this.client, process.env.MNEMONIC, process.env.HASH_CONTRACT);
    }
    async run() {
        try {
            const suiKeypair = Ed25519Keypair.deriveKeypair(process.env.MNEMONIC, "m/44'/784'/0'/0'/0'");
            const address = suiKeypair.toSuiAddress();
            console.log('Operation for address: ' + address);
            const result = await this.tx.mintCoins(process.env.MINING_CONTROLLER, process.env.BALANCE_KEEPER);
            console.log(result);
        }
        catch (err) {
            console.log(err);
        }
    }
}
const hash = new Mint();
hash.run();
//# sourceMappingURL=Mint.js.map