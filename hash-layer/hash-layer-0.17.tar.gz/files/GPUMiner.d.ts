import BSC from "./BSC.js";
import Chain from "./Chain.js";
import TXService from "./TXService.js";
import { MiningCoordinator } from "./MiningCoordinator.js";
export declare function getGPUCount(): number;
export declare class GPUMiner {
    private bsc;
    private chain;
    private txService;
    private iterationsPerBatch;
    private totalHashrate;
    private blocksFound;
    private gpuId;
    private gpuCount;
    private coordinator;
    constructor(bsc: BSC, chain: Chain, txService: TXService, iterationsPerBatch?: bigint, // 1B iterations per batch (1 миллиард)
    gpuId?: number, gpuCount?: number, coordinator?: MiningCoordinator | null);
    isAvailable(): boolean;
    private bufferToBigInt;
    private bigIntToBuffer;
    private numberToUint64;
    mineOnGPU(): Promise<void>;
    getStats(): {
        hashrate: number;
        blocksFound: number;
    };
}
//# sourceMappingURL=GPUMiner.d.ts.map