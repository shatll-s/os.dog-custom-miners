import koffi from "koffi";
import path from "path";
import { fileURLToPath } from "url";
// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Load CUDA library
const libPath = path.join(__dirname, "..", "libhashminer.so");
let cudaLib = null;
let mine_hash_layer = null;
let mine_hash_layer_on_device = null;
let get_device_count = null;
try {
    cudaLib = koffi.load(libPath);
    // Define the function signatures
    mine_hash_layer = cudaLib.func("mine_hash_layer", "int", [
        "uint64", // height
        "uint8 *", // previous_hash (32 bytes)
        "uint64", // nonce_start
        "uint32", // difficulty
        "uint64", // iterations
        "uint64 *", // result_nonce
        "uint8 *" // result_hash (32 bytes)
    ]);
    mine_hash_layer_on_device = cudaLib.func("mine_hash_layer_on_device", "int", [
        "uint64", // height
        "uint8 *", // previous_hash (32 bytes)
        "uint64", // nonce_start
        "uint32", // difficulty
        "uint64", // iterations
        "uint64 *", // result_nonce
        "uint8 *", // result_hash (32 bytes)
        "int" // gpu_id
    ]);
    get_device_count = cudaLib.func("get_device_count", "int", []);
    console.log("[CUDA] Library loaded successfully");
}
catch (err) {
    console.error("[ERROR] Failed to load CUDA library:", err);
    console.log(`Expected library at: ${libPath}`);
    console.log("Please run 'make' to compile the CUDA code first");
}
export function getGPUCount() {
    if (!get_device_count)
        return 0;
    return get_device_count();
}
export class GPUMiner {
    bsc;
    chain;
    txService;
    iterationsPerBatch;
    totalHashrate = 0;
    blocksFound = 0;
    gpuId;
    gpuCount;
    coordinator;
    constructor(bsc, chain, txService, iterationsPerBatch = 1000000000n, // 1B iterations per batch (1 миллиард)
    gpuId = 0, gpuCount = 1, coordinator = null) {
        this.bsc = bsc;
        this.chain = chain;
        this.txService = txService;
        this.iterationsPerBatch = iterationsPerBatch;
        this.gpuId = gpuId;
        this.gpuCount = gpuCount;
        this.coordinator = coordinator;
    }
    isAvailable() {
        return cudaLib !== null && mine_hash_layer !== null;
    }
    bufferToBigInt(buffer) {
        let result = 0n;
        for (let i = 0; i < 8; i++) {
            result |= BigInt(buffer[i]) << (BigInt(i) * 8n);
        }
        return result;
    }
    bigIntToBuffer(value) {
        const buffer = Buffer.alloc(8);
        for (let i = 0; i < 8; i++) {
            buffer[i] = Number((value >> (BigInt(i) * 8n)) & 0xffn);
        }
        return buffer;
    }
    numberToUint64(value) {
        // Ensure value fits in uint64
        return value & 0xffffffffffffffffn;
    }
    async mineOnGPU() {
        if (!mine_hash_layer_on_device) {
            throw new Error("CUDA library not available");
        }
        console.log(`[GPU ${this.gpuId}] Starting GPU mining on device ${this.gpuId}/${this.gpuCount - 1}...`);
        while (true) {
            try {
                // Get chain snapshot
                const snapshot = await this.chain.snapshot();
                if (!snapshot) {
                    console.error(`[ERROR] [GPU ${this.gpuId}] Failed to get chain snapshot`);
                    await new Promise((resolve) => setTimeout(resolve, 5000));
                    continue;
                }
                const { header, block_hash } = snapshot.fields.last_block.fields;
                const { difficulty } = snapshot.fields;
                const height = BigInt(header.fields.height);
                // Update coordinator with current height
                if (this.coordinator) {
                    this.coordinator.updateHeight(height);
                    // Check if we should continue mining this block
                    if (!this.coordinator.shouldContinueMining(height)) {
                        console.log(`[GPU ${this.gpuId}] Skipping block ${height}, switching to next`);
                        await new Promise((resolve) => setTimeout(resolve, 1000));
                        continue;
                    }
                }
                const startTime = Date.now();
                // Prepare buffers
                const previous_hash = Buffer.from(block_hash);
                const result_nonce = Buffer.alloc(8);
                const result_hash = Buffer.alloc(32);
                // Random starting nonce + offset per GPU to avoid collision
                const base_nonce = BigInt(Math.floor(Math.random() * 1e15));
                const nonce_offset = this.iterationsPerBatch * BigInt(this.gpuId);
                const nonce_start = base_nonce + nonce_offset;
                // Call CUDA kernel with specific GPU
                const found = mine_hash_layer_on_device(this.numberToUint64(height + 1n), previous_hash, this.numberToUint64(nonce_start), Number(difficulty), this.numberToUint64(this.iterationsPerBatch), result_nonce, result_hash, this.gpuId);
                const elapsed = (Date.now() - startTime) / 1000;
                const hashrate = Number(this.iterationsPerBatch) / elapsed;
                this.totalHashrate = hashrate;
                console.log(`[GPU ${this.gpuId}] Hashrate: ${(hashrate / 1_000_000).toFixed(2)} MH/s (block: ${height})`);
                if (found) {
                    const foundNonce = this.bufferToBigInt(result_nonce);
                    const foundHash = result_hash.toString("hex");
                    console.log(`[GPU ${this.gpuId}] BLOCK FOUND!`);
                    console.log(`   Nonce: ${foundNonce}`);
                    console.log(`   Hash: ${foundHash}`);
                    console.log(`   Difficulty: ${difficulty} bits`);
                    // Acquire exclusive submit lock if using coordinator
                    if (this.coordinator) {
                        await this.coordinator.acquireSubmitLock();
                    }
                    try {
                        await this.txService.sumbitBlock(foundNonce, [], new TextEncoder().encode(process.env.NFT_URL || ""), process.env.CHAIN_OBJECT || "", process.env.BALANCE_KEEPER || "");
                        this.blocksFound++;
                        console.log(`[GPU ${this.gpuId}] Block submitted! Total found: ${this.blocksFound}`);
                        // Notify coordinator that block was found
                        if (this.coordinator) {
                            this.coordinator.notifyBlockFound(height + 1n);
                        }
                    }
                    catch (err) {
                        if (err?.code === -32002) {
                            console.warn(`[GPU ${this.gpuId}] Rejected by validators (object conflict)`);
                        }
                        else {
                            console.error(`[ERROR] [GPU ${this.gpuId}] Block submission error:`, err);
                        }
                    }
                    finally {
                        // Always release lock
                        if (this.coordinator) {
                            this.coordinator.releaseSubmitLock();
                        }
                    }
                    // Wait a bit for chain to update
                    await new Promise((resolve) => setTimeout(resolve, 2000));
                }
            }
            catch (err) {
                console.error(`[ERROR] [GPU ${this.gpuId}] Mining error:`, err);
                await new Promise((resolve) => setTimeout(resolve, 5000));
            }
        }
    }
    getStats() {
        return {
            hashrate: this.totalHashrate,
            blocksFound: this.blocksFound,
        };
    }
}
//# sourceMappingURL=GPUMiner.js.map